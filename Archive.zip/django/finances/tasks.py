import logging
from background_task import background
from labelbase.models import Label
from finances.electrum import checkup_label

logger = logging.getLogger('labelbase')



@background(schedule={'run_at': 0}, remove_existing_tasks=True)
def check_all_outputs(user_id, loop=None):
    labels = Label.objects.filter(labelbase__user_id=user_id)
    for label in labels:
        if label.type == "output":
            check_spent(label.id)

@background(schedule={'run_at': 0}, remove_existing_tasks=True)
def check_spent(label_id, loop=None):
    if loop:
        checkup_label(label_id, loop)



"""


get utxo value in sats

txid = "52cf28b55b5e20274f6e3278e49b7d1b111733a497a7ec0272c03240685053be"
vout = "1"




txid = "18bf9e5740aea9191c132e3b352494ed5037b8081776c207692ce31963bdf3c6"
vout = 0


for all my labelbasels:
  for all my labels fo type = "output":
      call check_spent(f'{txid} {vout}')
"""
