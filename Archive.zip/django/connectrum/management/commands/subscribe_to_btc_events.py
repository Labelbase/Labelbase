from django.core.management.base import BaseCommand
from connectrum.client import StratumClient
from connectrum.svr_info import ServerInfo
import json
import asyncio

# python manage.py subscribe_to_btc_events blockchain.headers.subscribe --server=bitcoin.lu.ke --protocol=s --port=50002


class Command(BaseCommand):
    help = 'Subscribe to BTC events'

    def add_arguments(self, parser):
        parser.add_argument('method', help='"blockchain.headers.subscribe" or similar')
    #    parser.add_argument('args', nargs="*", default=[], help='Arguments for method')
        parser.add_argument('--server', default='cluelessperson.com', help='Hostname of Electrum server to use')
        parser.add_argument('--protocol', default='s', help='Protocol code: t=TCP Cleartext, s=SSL, etc')
        parser.add_argument('--port', default=None, help='Port number to override default for protocol')
        parser.add_argument('--tor', default=False, action="store_true", help='Use local Tor proxy to connect')

    def handle(self, *args, **options):
        svr = ServerInfo(options['server'], options['server'],
                         ports=((options['protocol'] + str(options['port'])) if options['port'] else options['protocol']))

        loop = asyncio.get_event_loop()
        conn = StratumClient()
        connector = conn.connect(svr, options['protocol'], use_tor=svr.is_onion, disable_cert_verify=True)
        loop.run_until_complete(self.listen(conn, svr, connector, options['method']))
        loop.close()


    async def listen(self, conn, svr, connector, method, verbose=0):
        try:
            await connector
        except Exception as e:
            print("Unable to connect to server: %s" % e)
            return -1

        print("\nConnected to: %s\n" % svr)

        if verbose:
            donate = await conn.RPC('server.donation_address')
            if donate:
                print("Donations: " + donate)

            motd = await conn.RPC('server.banner')
            print("\n---\n%s\n---" % motd)

        print("\nMethod: %s" % method)

        fut, q = conn.subscribe(method)
        print(json.dumps(await fut, indent=1))
        while 1:
            result = await q.get()
            print(json.dumps(result, indent=1))
