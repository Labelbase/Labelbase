from django import forms
from .models import Profile

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['avatar_url']
        labels = {
            'avatar_url': 'Paste the URL of your avatar image (JPEG, PNG, or GIF)',
        }
