Copy-and-pasted at commit https://github.com/coinkite/connectrum/commit/c893bc2100de6acebbdf0bf67b62e6cb9ce1c7be and extended for Labelbase.

MIT Licence https://github.com/coinkite/connectrum/blob/master/LICENSE
