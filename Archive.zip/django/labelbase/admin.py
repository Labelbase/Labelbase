from django.contrib import admin
from .models import Labelbase
from .models import Label

admin.site.register(Labelbase)
admin.site.register(Label)
