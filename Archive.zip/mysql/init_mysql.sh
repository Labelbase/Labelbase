#!/bin/bash

# Function to wait for MySQL to be ready
wait_for_mysql() {
  until mysqladmin ping -h db -u root -p"$MYSQL_ROOT_PASSWORD" --silent; do
    echo 'Waiting for MySQL to be ready...'
    sleep 1
  done
}

# Wait for MySQL to be ready
wait_for_mysql

# Alter root password
mysql -h db -u root -p"$MYSQL_ROOT_PASSWORD" -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$MYSQL_ROOT_PASSWORD';"

# Create database
mysql -h db -u root -p"$MYSQL_ROOT_PASSWORD" -e "CREATE DATABASE IF NOT EXISTS labelbase;"

# Create user and grant privileges
mysql -h db -u root -p"$MYSQL_ROOT_PASSWORD" -e "CREATE USER IF NOT EXISTS 'ulabelbase'@'%' IDENTIFIED BY '$MYSQL_PASSWORD';"
mysql -h db -u root -p"$MYSQL_ROOT_PASSWORD" -e "GRANT ALL PRIVILEGES ON labelbase.* TO 'ulabelbase'@'%';"

# Additional MySQL commands...

echo 'MySQL initialization completed.'
