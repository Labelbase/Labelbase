#
# Exceptions
#


class ElectrumErrorResponse(RuntimeError):
    pass
